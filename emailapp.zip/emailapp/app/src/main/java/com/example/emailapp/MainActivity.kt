package com.example.emailapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.emailapp.ui.theme.EmailAppTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            EmailAppTheme {
                EmailApp()
            }
        }
    }
}

@Composable
fun EmailApp() {
    var isLoggedIn by remember { mutableStateOf(false) }
    var isRegistering by remember { mutableStateOf(false) }

    when {
        isLoggedIn -> MailDashboard(onLogout = { isLoggedIn = false })
        isRegistering -> RegisterScreen(
            onRegisterSuccess = { isRegistering = false },
            onBackClick = { isRegistering = false }
        )
        else -> LoginScreen(
            onLoginSuccess = { isLoggedIn = true },
            onRegisterClick = { isRegistering = true }
        )
    }
}

@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun LoginScreen(onLoginSuccess: () -> Unit, onRegisterClick: () -> Unit) {
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    val keyboardController = LocalSoftwareKeyboardController.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "📧 Email App",
            fontSize = 32.sp,
            color = Color.Magenta,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(24.dp))

        OutlinedTextField(
            value = username,
            onValueChange = { username = it },
            label = { Text("Username") },
            singleLine = true,
            keyboardOptions = KeyboardOptions.Default.copy(imeAction = ImeAction.Next)
        )
        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Password") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions.Default.copy(imeAction = ImeAction.Done),
            keyboardActions = KeyboardActions(onDone = {
                keyboardController?.hide()
                onLoginSuccess()
            })
        )
        Spacer(modifier = Modifier.height(16.dp))

        Button(onClick = { onLoginSuccess() }) {
            Text("Login")
        }
        Spacer(modifier = Modifier.height(8.dp))

        Button(onClick = onRegisterClick, colors = ButtonDefaults.buttonColors(containerColor = Color.Magenta)) {
            Text("Register")
        }
    }
}

@Composable
fun RegisterScreen(onRegisterSuccess: () -> Unit, onBackClick: () -> Unit) {
    var username by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    val isValid by derivedStateOf { username.isNotBlank() && email.isNotBlank() && password.isNotBlank() }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "Register",
            fontSize = 32.sp,
            color = Color.Magenta,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        OutlinedTextField(
            value = username,
            onValueChange = { username = it },
            label = { Text("Username") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("Email") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Password") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(16.dp))

        Row(
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Button(
                onClick = { if (isValid) onRegisterSuccess() },
                enabled = isValid,
                colors = ButtonDefaults.buttonColors(containerColor = Color.Green),
                modifier = Modifier.weight(1f)
            ) {
                Text("Register")
            }

            Button(
                onClick = onBackClick,
                colors = ButtonDefaults.buttonColors(containerColor = Color.Gray),
                modifier = Modifier.weight(1f)
            ) {
                Text("Back")
            }
        }
    }
}

@Composable
fun MailDashboard(onLogout: () -> Unit) {
    var viewInbox by remember { mutableStateOf(false) }
    var composeMail by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "Welcome to Email!",
            fontSize = 28.sp,
            color = Color.Magenta,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = { viewInbox = true },
            colors = ButtonDefaults.buttonColors(containerColor = Color.Cyan)
        ) {
            Text("View Inbox")
        }
        Spacer(modifier = Modifier.height(8.dp))

        Button(
            onClick = { composeMail = true },
            colors = ButtonDefaults.buttonColors(containerColor = Color.Green)
        ) {
            Text("Compose Mail")
        }
        Spacer(modifier = Modifier.height(16.dp))

        Button(onClick = onLogout, colors = ButtonDefaults.buttonColors(containerColor = Color.Red)) {
            Text("Logout")
        }

        if (viewInbox) {
            InboxScreen(onBackClick = { viewInbox = false })
        }
        if (composeMail) {
            ComposeMailScreen(onBackClick = { composeMail = false })
        }
    }
}

@Composable
fun InboxScreen(onBackClick: () -> Unit) {
    val fakeEmails = listOf(
        "Hello! Welcome to Email.",
        "Your account has been activated.",
        "Reminder: Update your settings."
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(text = "Inbox", fontSize = 28.sp, color = Color.Black)
        Spacer(modifier = Modifier.height(16.dp))

        fakeEmails.forEach { email ->
            Text(text = "📩 $email", fontSize = 18.sp, color = Color.DarkGray)
            Spacer(modifier = Modifier.height(8.dp))
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(onClick = onBackClick, colors = ButtonDefaults.buttonColors(containerColor = Color.Gray)) {
            Text("Back")
        }
    }
}

@Composable
fun ComposeMailScreen(onBackClick: () -> Unit) {
    var recipient by remember { mutableStateOf("") }
    var subject by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(text = "Compose Email", fontSize = 28.sp, color = Color.Black)
        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = recipient,
            onValueChange = { recipient = it },
            label = { Text("Recipient") },
            singleLine = true
        )
        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = subject,
            onValueChange = { subject = it },
            label = { Text("Subject") },
            singleLine = true
        )
        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = message,
            onValueChange = { message = it },
            label = { Text("Message") },
            modifier = Modifier.fillMaxHeight(0.4f)
        )
        Spacer(modifier = Modifier.height(16.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { /* Simulate sending mail */ }) {
                Text("Send")
            }
            Button(onClick = onBackClick, colors = ButtonDefaults.buttonColors(containerColor = Color.Gray)) {
                Text("Back")
            }
        }
    }
}
